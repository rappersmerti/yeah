Target Encoder
==============

.. autoclass:: category_encoders.target_encoder.TargetEncoder
    :members:
