Leave One Out
=============

.. autoclass:: category_encoders.leave_one_out.LeaveOneOutEncoder
    :members:
