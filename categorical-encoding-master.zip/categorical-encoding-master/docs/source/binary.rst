Binary
======

.. autoclass:: category_encoders.binary.BinaryEncoder
    :members:
