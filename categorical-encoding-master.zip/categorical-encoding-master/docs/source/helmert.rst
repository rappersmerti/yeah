Helmert Coding
==============

.. autoclass:: category_encoders.helmert.HelmertEncoder
    :members:
