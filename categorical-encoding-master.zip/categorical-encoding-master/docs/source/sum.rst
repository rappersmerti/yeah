Sum Coding
==========

.. autoclass:: category_encoders.sum_coding.SumEncoder
    :members:
